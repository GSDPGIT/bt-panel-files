System.register(["./base-lib-legacy.js?v=1761640445"],function(e,t){"use strict";var r;return{setters:[function(e){r=e.r}],execute:function(){r("list"),e("i",r(!1)),e("d",r({operateType:"add"}))}}});
