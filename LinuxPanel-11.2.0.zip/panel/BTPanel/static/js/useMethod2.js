import{r as s}from"./base-lib.js?v=1761640445";s("list");const a=s(!1),e=s({operateType:"add"});export{e as d,a as i};
