import{r as s}from"./base-lib.js?v=1761640445";const a=s({}),o=s({});export{o as a,a as t};
