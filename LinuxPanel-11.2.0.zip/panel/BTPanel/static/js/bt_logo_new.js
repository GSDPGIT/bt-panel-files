const e=""+new URL("../images/other/bt_logo_new.png",import.meta.url).href;export{e as _};
